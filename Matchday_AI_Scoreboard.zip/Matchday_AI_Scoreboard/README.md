# Matchday Scoreboard (API)

UI terinspirasi oleh screenshot pengguna: tema gelap, tab Today/Tomorrow, daftar fixture, skor, detail statistik dan info absen. Tidak menyalin merek/aset proprietari. Tidak menampilkan odds, handicap, atau saran taruhan.

## Jalankan lokal
1. Node.js 18+
2. Salin `.env.example` menjadi `.env`, masukkan API key API-Football.
3. `npm install`
4. `npm start`
5. Buka http://localhost:3000

## Deploy publik
Deploy project ke hosting Node (mis. Render/Railway). Set environment variable `API_FOOTBALL_KEY` di dashboard hosting, lalu deploy. Jangan commit `.env`. Untuk hosting static saja, backend proxy diperlukan agar key tidak bocor.

API-Football docs: https://www.api-football.com/documentation-v3
Sumber alternatif seperti SofaScore/Flashscore: gunakan hanya akses/API yang berizin; jangan mengandalkan scraping halaman publik karena dapat melanggar ketentuan layanan dan mudah rusak.
